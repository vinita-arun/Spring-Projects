package org.capgemini.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capgemini.pojo.Employee;
import org.capgemini.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	@RequestMapping("/empForm")
	public String showEmpForm(Map<String, Object> maps){
		
		List<Employee> employees= employeeService.getAllEmployees();
		 
		maps.put("emp",new Employee());
		maps.put("emps",employees);
		
		 
		 return "employee";
	}
	
	@RequestMapping(value="/showEmployee",method=RequestMethod.POST)
	public String showEmpDetails(@Valid @ModelAttribute("emp") Employee emp, BindingResult result){
		if(result.hasErrors())
			return "employee";
		else{
		
			employeeService.saveEmployee(emp);
			return "redirect:/empForm";
		}
	}
	
	@RequestMapping("/deleteEmployee/{empId}")
	public String deleteEmployee(@PathVariable("empId") Integer empId){
		employeeService.deleteEmployee(empId);
		return "redirect:/empForm";
	}
	
	
}
