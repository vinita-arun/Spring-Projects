package org.capgemini.controller;

import org.capgemini.pojo.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	
	@RequestMapping("/hello")
	public ModelAndView showHello(){
		return new ModelAndView("helloPage", "message", "HelloWorld!!!");
	}
	
	@RequestMapping("/empForm")
	public ModelAndView showEmpPage(){
		return new ModelAndView("employee", "employee", new Employee());
	}
	
	@RequestMapping(value="/showEmployee",method=RequestMethod.POST)
	public String showEmpDetails(@ModelAttribute("employee") Employee emp){
		return "showEmp";
	}

}
